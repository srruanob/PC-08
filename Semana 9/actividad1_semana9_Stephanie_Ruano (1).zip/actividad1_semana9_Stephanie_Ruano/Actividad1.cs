﻿class claseSemana9Actividad1
{
   static void Main()
   {
       int num;
       bool esPrimo = true;

       Console.WriteLine("Ingrese un número positivo con un máximo de 6 cifras: ");
       num = Convert.ToInt32(Console.ReadLine());

       if (num <= 0 || num > 999999)
       {
        Console.WriteLine("Número fuera de rango, máximo 6 cifras");
       }
       else if (num == 1)
       {
        Console.WriteLine("Número 1 no es primo");
       }
       else 
       {
        for (int i = 2; i <= num / 2; i++)
        {
            if (num % i == 0)
            {
                esPrimo = false; 
                break;
            }
        }
        if (esPrimo)
        {
            Console.WriteLine("El número es primo.");
        }
        else
        {
            Console.WriteLine("El número no es primo.");
        }

       } 
   }
 
}