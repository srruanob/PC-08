using System;

namespace semana_18;

public class notasAlumnos
{
       public class NotasAlumnos
    {
        public string Nombre { get; set; }
        public int[] Notas { get; set; }

        public NotasAlumnos(string nombre)
        {
            Nombre = nombre;
            Notas = new int[10];
        }

        public List<int> NotasAprobadas()
        {
            List<int> aprobadas = new List<int>();
            foreach (int nota in Notas)
            {
                if (nota >= 65)
                {
                    aprobadas.Add(nota);
                }
            }
            return aprobadas;
        }

        public List<int> NotasNoAprobadas()
        {
            List<int> noAprobadas = new List<int>();
            foreach (int nota in Notas)
            {
                if (nota < 65)
                {
                    noAprobadas.Add(nota);
                }
            }
            return noAprobadas;
        }

        public double CalcularPromedio()
        {
            return Notas.Average();
        }
    }
}
