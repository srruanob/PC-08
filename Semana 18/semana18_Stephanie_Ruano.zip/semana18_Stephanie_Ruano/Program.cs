﻿namespace semana_18;

class Program
{
    static void Main(string[] args)
    {
         NotasAlumnos[] alumnos = new NotasAlumnos[10];

            Console.WriteLine("=== INGRESO DE ALUMNOS ===");

            for (int i = 0; i < 10; i++)
            {
                Console.Write($"\nIngrese el nombre del alumno #{i + 1}: ");
                string nombre = Console.ReadLine();

                NotasAlumnos alumno = new NotasAlumnos(nombre);

                for (int j = 0; j < 10; j++)
                {
                    alumno.Notas[j] = PedirNota(j + 1);
                }

                alumnos[i] = alumno;
            }

            bool salir = false;

            while (!salir)
            {
                Console.WriteLine("\n=== MENÚ ===");
                Console.WriteLine("1) Ver alumnos y sus notas aprobadas");
                Console.WriteLine("2) Ver alumnos y sus notas no aprobadas");
                Console.WriteLine("3) Ver promedio general del grupo");
                Console.WriteLine("4) Salir");
                Console.Write("Elija una opción: ");
                string opcion = Console.ReadLine();

                if (opcion == "1")
                {
                    MostrarNotas(alumnos, true);
                }
                else if (opcion == "2")
                {
                    MostrarNotas(alumnos, false);
                }
                else if (opcion == "3")
                {
                    MostrarPromedioGrupo(alumnos);
                }
                else if (opcion == "4")
                {
                    salir = true;
                    Console.WriteLine("Gracias por usar el programa.");
                }
                else
                {
                    Console.WriteLine("Opción inválida. Intente de nuevo.");
                }
            }
        }

        static int PedirNota(int numeroNota)
        {
            int nota;

            while (true)
            {
                Console.Write($"Ingrese la nota #{numeroNota} (entre 0 y 100): ");
                string entrada = Console.ReadLine();

                if (int.TryParse(entrada, out nota))
                {
                    if (nota >= 0 && nota <= 100)
                    {
                        return nota;
                    }
                }

                Console.WriteLine("Nota inválida. Debe ser un número entre 0 y 100.");
            }
        }

        static void MostrarNotas(NotasAlumnos[] alumnos, bool mostrarAprobadas)
        {
            foreach (var alumno in alumnos)
            {
                Console.WriteLine($"\nAlumno: {alumno.Nombre}");

                var listaNotas = mostrarAprobadas
                    ? alumno.NotasAprobadas()
                    : alumno.NotasNoAprobadas();

                if (listaNotas.Count == 0)
                {
                    Console.WriteLine("No tiene notas en esta categoría.");
                }
                else
                {
                    Console.WriteLine("Notas: " + string.Join(", ", listaNotas));
                }
            }
        }

        static void MostrarPromedioGrupo(NotasAlumnos[] alumnos)
        {
            double sumaPromedios = 0;

            foreach (var alumno in alumnos)
            {
                sumaPromedios += alumno.CalcularPromedio();
            }

            double promedioGeneral = sumaPromedios / alumnos.Length;

            Console.WriteLine($"\nEl promedio del grupo es: {promedioGeneral:F2}");
        }
    }