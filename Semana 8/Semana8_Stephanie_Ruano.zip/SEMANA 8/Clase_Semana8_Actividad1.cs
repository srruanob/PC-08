﻿class ClaseSemana8Actividad1
{
    static void Main()
    {
        string numeroIngresado = "";
        int numeroInicial = 0; 
        while (true)
        {
          Console.WriteLine("Ingrese un número entero: ");
          numeroIngresado = Console.ReadLine();
            if(int.TryParse(numeroIngresado, out numeroInicial))
            {
                break;
            }
            else
            {
                Console.WriteLine("Entrada inválida. Inténtalo de nuevo.");
            }
        }
        int resultadoFinal = CalcularFactorial(numeroInicial);

        Console.WriteLine($"El factorial de {numeroIngresado}: {resultadoFinal}");
    }
    public static int CalcularFactorial(int numeroInicial)
        {
            if(numeroInicial == 0)
            {
                return 1;
            }
            else 
            {
                int factorial = 1; 
                for (int i = 1; i<= numeroInicial; i++)
                {
                    factorial *= i; 
                }
                return factorial; 
            }

        }
}

